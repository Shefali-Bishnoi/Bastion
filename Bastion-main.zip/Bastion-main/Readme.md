BASTION

##########################################

A base-building game 

<img width="511" alt="image" src="https://github.com/user-attachments/assets/553e2f4f-8c77-4cf0-bf84-fab6554b43dd" />

This was written as a CS project for group 2 

A basic overview of the file structure (so far is)

Source:
Contains C files,header and other programming related items

Resources
Contains external resources which our game will need like images,fonts,sounds,etc.

Release
Contains the final .exe executable along with additional assets 
